vuser_end()
{

	lr_think_time(24);

	web_url("note.jpg", 
		"URL=http://www.scholat.com/images/homepage/note.jpg", 
		"Resource=1", 
		"RecContentType=image/jpeg", 
		"Referer=http://www.scholat.com/portalSearchScholarS.html?q=%E6%9D%8E%E7%A5%BA", 
		"Snapshot=t23.inf", 
		LAST);

	web_url("makefriend.jpg", 
		"URL=http://www.scholat.com/images/homepage/makefriend.jpg", 
		"Resource=1", 
		"RecContentType=image/jpeg", 
		"Referer=http://www.scholat.com/portalSearchScholarS.html?q=%E6%9D%8E%E7%A5%BA", 
		"Snapshot=t24.inf", 
		LAST);

	web_url("logout.html", 
		"URL=http://www.scholat.com/logout.html", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=http://www.scholat.com/portalSearchScholarS.html?q=%E6%9D%8E%E7%A5%BA", 
		"Snapshot=t25.inf", 
		"Mode=HTML", 
		LAST);

	return 0;
}