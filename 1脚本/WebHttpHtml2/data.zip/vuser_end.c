vuser_end()
{

	web_url("logout.html", 
		"URL=http://www.scholat.com/logout.html", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=http://www.scholat.com/editUserProfile.html", 
		"Snapshot=t73.inf", 
		"Mode=HTML", 
		LAST);

	web_add_cookie("JSESSIONID=4844E04D72716F94CB6E262A3D340780.tomcat1; DOMAIN=www.scholat.com");

	web_add_cookie("STOKEN=\"E64478C5D0095A74/2018-06-04 09:25:36/611d53e40d8ce3099a3c9beb02111e81&desc=1217\"; DOMAIN=www.scholat.com");

	web_custom_request("ChatMng.logout.dwr", 
		"URL=http://www.scholat.com/dwr/call/plaincall/ChatMng.logout.dwr", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=text/javascript", 
		"Referer=http://www.scholat.com/editUserProfile.html", 
		"Snapshot=t74.inf", 
		"Mode=HTML", 
		"EncType=text/plain", 
		"Body=callCount=1\npage=/editUserProfile.html\nhttpSessionId=\nscriptSessionId=CD9326009CAA68019290557EA8A1C643123\nc0-scriptName=ChatMng\nc0-methodName=logout\nc0-id=0\nc0-param0=string:17449\nc0-param1=string:Ah\nc0-param2=boolean:false\nbatchId=1\n", 
		LAST);

	return 0;
}