Action()
{

	lr_think_time(34);

	lr_start_transaction("Seeimformation");

	web_url("editUserProfile.html", 
		"URL=http://www.scholat.com/editUserProfile.html", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=http://www.scholat.com/Phomepage.html", 
		"Snapshot=t58.inf", 
		"Mode=HTML", 
		LAST);

	web_custom_request("getDynamicMessagesMobile.html_2", 
		"URL=http://www.scholat.com//getDynamicMessagesMobile.html", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=http://www.scholat.com/editUserProfile.html", 
		"Snapshot=t59.inf", 
		"Mode=HTML", 
		"EncType=", 
		LAST);

	web_custom_request("getAllAddFriendsMsg.html_2", 
		"URL=http://www.scholat.com//getAllAddFriendsMsg.html", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=http://www.scholat.com/editUserProfile.html", 
		"Snapshot=t60.inf", 
		"Mode=HTML", 
		"EncType=", 
		LAST);

	web_custom_request("checkMobileApplyInfo.html_2", 
		"URL=http://www.scholat.com//checkMobileApplyInfo.html", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=http://www.scholat.com/editUserProfile.html", 
		"Snapshot=t61.inf", 
		"Mode=HTML", 
		"EncType=", 
		LAST);

	web_custom_request("AllScholarShare.html_2", 
		"URL=http://www.scholat.com//AllScholarShare.html", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=http://www.scholat.com/editUserProfile.html", 
		"Snapshot=t62.inf", 
		"Mode=HTML", 
		"EncType=", 
		LAST);

	web_custom_request("SharePatent.html_2", 
		"URL=http://www.scholat.com//SharePatent.html", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=http://www.scholat.com/editUserProfile.html", 
		"Snapshot=t63.inf", 
		"Mode=HTML", 
		"EncType=", 
		LAST);

	web_custom_request("getAllCourseInvitationsAndApplications.html_2", 
		"URL=http://www.scholat.com//getAllCourseInvitationsAndApplications.html", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=http://www.scholat.com/editUserProfile.html", 
		"Snapshot=t64.inf", 
		"Mode=HTML", 
		"EncType=", 
		LAST);

	web_custom_request("mobileCalendarShare.html_2", 
		"URL=http://www.scholat.com//mobileCalendarShare.html", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=http://www.scholat.com/editUserProfile.html", 
		"Snapshot=t65.inf", 
		"Mode=HTML", 
		"EncType=", 
		LAST);

	web_custom_request("emailM-getUnreadCount.html_2", 
		"URL=http://www.scholat.com//emailM-getUnreadCount.html", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=http://www.scholat.com/editUserProfile.html", 
		"Snapshot=t66.inf", 
		"Mode=HTML", 
		"EncType=", 
		LAST);

	web_custom_request("ScholarUserType.html_2", 
		"URL=http://www.scholat.com//ScholarUserType.html", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=http://www.scholat.com/editUserProfile.html", 
		"Snapshot=t67.inf", 
		"Mode=HTML", 
		"EncType=", 
		EXTRARES, 
		"Url=http://202.116.32.240/scholat/images/avatar/bgshadow.gif", "Referer=http://www.scholat.com/setavatar.html?currentPicUrl=/images/default.png", ENDITEM, 
		LAST);

	web_url("null", 
		"URL=http://www.scholat.com/avatartmp/null", 
		"Resource=0", 
		"Referer=http://www.scholat.com/setavatar.html?currentPicUrl=/images/default.png", 
		"Snapshot=t68.inf", 
		"Mode=HTML", 
		EXTRARES, 
		"Url=../teamwork/img/FileBtn.jpg", "Referer=http://www.scholat.com/setavatar.html?currentPicUrl=/images/default.png", ENDITEM, 
		"Url=http://202.116.32.240/scholat/images/avatar/canvas.png", "Referer=http://www.scholat.com/setavatar.html?currentPicUrl=/images/default.png", ENDITEM, 
		"Url=http://202.116.32.240/scholat/images/avatar/packslider.png", "Referer=http://www.scholat.com/setavatar.html?currentPicUrl=/images/default.png", ENDITEM, 
		"Url=http://202.116.32.240/scholat/images/avatar/track.png", "Referer=http://www.scholat.com/setavatar.html?currentPicUrl=/images/default.png", ENDITEM, 
		LAST);

	web_custom_request("ChatMng.update.dwr_2", 
		"URL=http://www.scholat.com/dwr/call/plaincall/ChatMng.update.dwr", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=text/javascript", 
		"Referer=http://www.scholat.com/editUserProfile.html", 
		"Snapshot=t69.inf", 
		"Mode=HTML", 
		"EncType=text/plain", 
		"Body=callCount=1\npage=/editUserProfile.html\nhttpSessionId=\nscriptSessionId=CD9326009CAA68019290557EA8A1C643123\nc0-scriptName=ChatMng\nc0-methodName=update\nc0-id=0\nc0-param0=string:Ah\nc0-param1=string:.%2F%2Fimages%2Fdefault.png\nc0-param2=boolean:false\nbatchId=0\n", 
		LAST);

	web_submit_data("RecentTreeActionForChat.html_2", 
		"Action=http://www.scholat.com/RecentTreeActionForChat.html?acc_id=17449", 
		"Method=POST", 
		"RecContentType=application/json", 
		"Referer=http://www.scholat.com/editUserProfile.html", 
		"Snapshot=t70.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=node", "Value=xnode-13", ENDITEM, 
		LAST);

	web_submit_data("FriendTreeActionForChat.html_2", 
		"Action=http://www.scholat.com/FriendTreeActionForChat.html?acc_id=17449", 
		"Method=POST", 
		"RecContentType=application/json", 
		"Referer=http://www.scholat.com/editUserProfile.html", 
		"Snapshot=t71.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=node", "Value=xnode-12", ENDITEM, 
		LAST);

	web_submit_data("TeamTreeActionForChat.html_2", 
		"Action=http://www.scholat.com/TeamTreeActionForChat.html?acc_id=17449", 
		"Method=POST", 
		"RecContentType=application/json", 
		"Referer=http://www.scholat.com/editUserProfile.html", 
		"Snapshot=t72.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=node", "Value=xnode-14", ENDITEM, 
		LAST);

	web_find("Text Check", "What=���ϴ����˽�����ʵ��Ƭ", LAST);

	lr_end_transaction("Seeimformation",LR_AUTO);

	return 0;
}
